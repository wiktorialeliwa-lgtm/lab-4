# Przepis na jajecznicę

## Potrzebne składniki

- [] jajka
- [] masło
- [] mleko
- [] sól i pieprz
- [] cebula
- [] boczek

## Lista zadań (to do)

- [] podsmażyć posiekaną cebulkę na maśle
- [] podsmażyć boczek
- [] wbić jajka do miski i rozmieszać razem z odrobiną mleka, soli i pieprzu
- [] usmażyć jajka wraz z cebulką

## Opis krok po kroku

Na początku procesu robienia jajecznicy podsmaż posiekaną cebulkę na odrobinie masła aż zrobi się złocista. Następnie odłóż cebulkę na bok i podsmaż boczek na tej samej patelni. Wbij jajka do miski i rozmieszaj z odrobiną mleka, soli i pieprzu. Wlej jajka na rozgrzaną patelnie i smaż na maśle razem z cebulką. Mieszaj jajecznicę na patelni do uzyskania zadowalającej konsystencji. Podaj z przygotowanym wcześniej boczkiem. Gotowe!

Przydatne linki:
- [Podobny przepis ze zdjęciami krok po kroku] (https://aniagotuje.pl/przepis/jajecznica)
- [Przepis na omleta z warzywami] (https://aniagotuje.pl/przepis/omlet-z-warzywami)